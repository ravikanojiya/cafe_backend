const express = require("express");
require("dotenv").config();
const app = express();
var cors = require("cors");
const userRouter = require("./apis/users/router");
const categoryRouter = require("./apis/category/router");
const productRouter = require("./apis/products/router");
const dashboardRouter = require("./apis/dashboard/router");
app.use(express.json());
app.use(cors());
app.use("/user", userRouter);
app.use("/category", categoryRouter);
app.use("/product", productRouter);
app.use("/dashboard", dashboardRouter);

app.listen(process.env.APP_PORT, () => {
  console.log("Server is running...!!", process.env.APP_PORT);
});
